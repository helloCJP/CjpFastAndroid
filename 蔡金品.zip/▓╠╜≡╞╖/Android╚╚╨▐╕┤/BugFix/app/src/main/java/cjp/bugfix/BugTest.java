package cjp.bugfix;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by chilies on 2020/2/13.
 * 不打酱油的程序员不是好码农
 */
public class BugTest {

    public void getBug(Context context) {
        //模拟一个bug
        int i = 10;
        int a = 0; // 制造bug
//         int a = 1;// 修复bug
        Toast.makeText(context, "Hello,Minuit:" + i / a, Toast.LENGTH_SHORT).show();
    }
}







