package cjp.bugfix;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Created by chilies on 2020/2/13.
 * 不打酱油的程序员不是好码农
 */
public class MainActivity extends AppCompatActivity {

    Button btnFix;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        new BugTest().getBug(MainActivity.this);
    }


    private void init() {
        btnFix = findViewById(R.id.btn_fix);
    }

}