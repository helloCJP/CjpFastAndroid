package c.cjp.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import c.cjp.myapplication.gtn.GtnManager;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;

public class MainActivity extends AppCompatActivity {
    private static String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        GtnManager.getInstance().setListener(new GtnManager.GtnListener() {
            @Override
            public void onGtnValue(String value) {
                Log.i(TAG, "onGtnValue: " + value);
            }
        });

    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        // 过滤非正常按键事件
        boolean result = GtnManager.getInstance().analysisKeyEvent(event);
        if (result){
            return true;
        }
        return super.dispatchKeyEvent(event);
    }
}
