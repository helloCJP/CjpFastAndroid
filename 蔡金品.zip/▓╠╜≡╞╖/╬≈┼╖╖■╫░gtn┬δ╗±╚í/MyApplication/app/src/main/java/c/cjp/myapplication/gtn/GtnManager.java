package c.cjp.myapplication.gtn;

import android.app.Activity;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;

import c.cjp.myapplication.BuildConfig;

/**
 * Created by chilies on 2020/2/11.
 * 不打酱油的程序员不是好码农
 */
public class GtnManager {
    private static final String TAG = GtnManager.class.getSimpleName();

    private static final int GTN_MIN_LENGTH = 13;
    private static final int GTN_MAX_LENGTH = 14;
    // 两次完整输入之间的最小时间
    private static final int GTN_MIN_VALUE_TIME = 3000;
    // 两次code事件之间最大时间
    private static final int GTN_MAX_CODE_TIME = 10000;

    private static GtnManager instance;
    private GtnListener listener;
    // gtn 数据
    private StringBuilder gtnValue = new StringBuilder();
    private long lastGtnTime = 0;
    private long lastCodeTime = 0;

    private Activity currentActivity;


    public static synchronized GtnManager getInstance() {
        if (instance == null){
            synchronized (GtnManager.class){
                if (instance == null){
                    instance = new GtnManager();
                }
            }
        }
        return instance;
    }


    public void setListener(GtnListener listener){
        this.listener = listener;
    }

    public void setCurrentActivity(Activity activity){
        currentActivity = activity;
    }

    /**
     * 分析按键事件
     * @param event 按键事件
     * @return 是否拦截
     */
    public boolean analysisKeyEvent(KeyEvent event) {
        if (isEffectKeyCode(event)){
            // 是有效事件
            int keyCode = event.getKeyCode();
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                // 当前为确认按键 代表一次输入完成
                if (keyCode == KeyEvent.KEYCODE_ENTER
                        && (gtnValue.length() >= GTN_MIN_LENGTH && gtnValue.length() <= GTN_MAX_LENGTH)) {
                    // 判断是否为有效长度， 需求为 13、14 位
                    String value = gtnValue.toString();
                    gtnValue.delete(0, gtnValue.length());
                    if (listener != null) {
                        if (System.currentTimeMillis() - lastGtnTime >= GTN_MIN_VALUE_TIME){
                            lastGtnTime = System.currentTimeMillis();
                            listener.onGtnValue(value);
                        }
                        return true;
                    }
                }

                // 获取数值
                String value = keyValue( event.getKeyCode());
                if (TextUtils.isEmpty(value)) {
                    // 两次code事件间隔大于10S 则移除之前记录的数据
                    if (System.currentTimeMillis() - lastCodeTime > GTN_MAX_CODE_TIME){
                        lastCodeTime = System.currentTimeMillis();
                        gtnValue.delete(0, gtnValue.length());
                    }
                    gtnValue.append(value);
                    return true;
                }
            }
        }
        return false;
    }


    /**
     * 判断当前是否为gtn有效数据
     * @param event 按键事件
     * @return true 为有效数据；false 为无效数据
     */
    private boolean isEffectKeyCode(KeyEvent event){
        // 判断当前焦点是否在EditView上， 如果在，则不交由系统处理
        if (currentActivity != null){
            View view = currentActivity.getCurrentFocus();
            if (view != null && view instanceof EditText){
                Log.w(TAG, "isEffectKeyCode: focus view is EditText");
                return false;
            }
        }

        // TODO: 2020/2/11 1.判断虚拟键盘还是实体键盘 ； 2.判断输入的keycode 是否有效
        if (!BuildConfig.DEBUG && event.getSource() != InputDevice.SOURCE_KEYBOARD){
            Log.w(TAG, "isEffectKeyCode: source is not keyboard");
            return false;
        }

        int code = event.getKeyCode();
        // 0-9   A-Z  确认
        if ((code >= KeyEvent.KEYCODE_0 && code <= KeyEvent.KEYCODE_9)
                || (code >= KeyEvent.KEYCODE_A &&  code <= KeyEvent.KEYCODE_Z)
                || (code == KeyEvent.KEYCODE_ENTER)){
            return true;
        }
        return false;
    }

    /**
     * 按键对应的char表
     */
    private String keyValue( int keyCode) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_0:
                return "0";
            case KeyEvent.KEYCODE_1:
                return "1";
            case KeyEvent.KEYCODE_2:
                return "2";
            case KeyEvent.KEYCODE_3:
                return "3";
            case KeyEvent.KEYCODE_4:
                return "4";
            case KeyEvent.KEYCODE_5:
                return "5";
            case KeyEvent.KEYCODE_6:
                return "6";
            case KeyEvent.KEYCODE_7:
                return "7";
            case KeyEvent.KEYCODE_8:
                return "8";
            case KeyEvent.KEYCODE_9:
                return "9";
            case KeyEvent.KEYCODE_A:
                return "A";
            case KeyEvent.KEYCODE_B:
                return "B";
            case KeyEvent.KEYCODE_C:
                return "C";
            case KeyEvent.KEYCODE_D:
                return "D";
            case KeyEvent.KEYCODE_E:
                return "E";
            case KeyEvent.KEYCODE_F:
                return "F";
        }
        return "";
    }

    /**
     * 回调
     */
    public interface GtnListener{
        void onGtnValue(String value);
    }


}
